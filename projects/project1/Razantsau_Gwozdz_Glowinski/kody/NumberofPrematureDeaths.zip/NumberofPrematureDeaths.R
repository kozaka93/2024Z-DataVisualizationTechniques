library(ggplot2)
library(maps)
library(mapdata)
library(dplyr)
library(rnaturalearth)
library(sf)
library(tidyverse)
library(ggthemes)
library(maps)

data <- read.csv("data.csv")

dataN <- data %>% 
  filter(Indicator=="Alcohol-attributable all-cause deaths per 100,000, age standardized",
         Dim1=="Both sexes",
         Dim2=="All age groups (total)")


w1 <- map_data("world")

w1 <- w1 %>% 
  filter(region != "Antarctica")

#dodanie pominietych danych
df1 = data_frame(region = "Greenland", FactValueNumeric = 74.2)
df2 = data.frame(region = "South Sudan" , FactValueNumeric = 38.4)

dataN <- dataN %>% 
  mutate(region = case_when(SpatialDimValueCode=="CZE"~"Czech Republic",
                            SpatialDimValueCode=="USA"~"USA",
                            SpatialDimValueCode=="BOL"~"Bolivia",
                            SpatialDimValueCode=="IRN"~"Iran",
                            SpatialDimValueCode=="COG"~"Republic of Congo",
                            SpatialDimValueCode=="TZA"~"Tanzania",
                            SpatialDimValueCode=="VNM"~"Vietnam",
                            SpatialDimValueCode=="LAO"~"Laos",
                            SpatialDimValueCode=="KOR"~"South Korea",
                            SpatialDimValueCode=="PRK"~"North Korea",
                            SpatialDimValueCode=="RUS"~"Russia",
                            SpatialDimValueCode=="MDA"~"Moldova",
                            SpatialDimValueCode=="VEN"~"Venezuela",
                            SpatialDimValueCode=="GBR"~"UK",
                            SpatialDimValueCode=="TUR"~"Turkey",
                            SpatialDimValueCode=="CIV"~"Ivory Coast",
                            SpatialDimValueCode=="SYR"~"Syria",
                            TRUE ~ Location)) %>% 
  rows_insert(df1) %>% 
  rows_insert(df2)



world <- dataN %>% 
  right_join(w1,by="region")


plain <- theme(
  axis.text = element_blank(),
  axis.line = element_blank(),
  axis.ticks = element_blank(),
  panel.border = element_blank(),
  panel.grid = element_blank(),
  axis.title = element_blank(),
  panel.background = element_rect(fill = "#efe4c9"),
  plot.background = element_rect(fill = "#efe4c9"),
  legend.background = element_rect(fill = "#efe4c9"),
  legend.frame = element_rect())



worldPDR <- ggplot(data = world, mapping = aes(x = long, y = lat, group = group, alpha = "")) + 
  coord_fixed(1.3) +
  geom_polygon(aes(fill = FactValueNumeric),colour = "gray45",lwd = 0.01) +
  scale_fill_fermenter(breaks = seq(20,140,30),direction = 1,palette = "Reds", na.value = "grey45")+
  theme(legend.title.position = "top",legend.key.height = unit(0.4,"cm"),legend.key.width = unit(2.4,"cm"))+
  theme(title = element_text(size = 16))+
  theme(legend.title = element_text(size = 15),legend.text = element_text(size=13))+
  theme(legend.position = "bottom")+
  labs(fill = "Number of deaths per 100,000 people")+
  scale_alpha_manual("No data", values = 1) +
  guides(fill = guide_colorsteps(order = 2), alpha = guide_legend(order = 1, override.aes = list(fill = "grey45")))+
  plain

worldPDR
