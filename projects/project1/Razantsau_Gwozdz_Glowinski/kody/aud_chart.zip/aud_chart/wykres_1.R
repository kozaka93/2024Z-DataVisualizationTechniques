library(dplyr)
library(ggplot2)
library(scales)
library(ggrepel)
library(RColorBrewer)
library(patchwork)


who_data <- read.csv('./alcohol_consumption.csv')
ihme_data <- read.csv('./alcohol_use_disorder.csv')



unique_values_who <- unique(who_data$Location)

unique_values_ihme <- unique(ihme_data$location_name)




standardize_country_name <- function(names) {
  prefixes_suffixes <- c(
    "Republic of ", "Democratic Republic of ", "Kingdom of ", "State of ",
    "Federal Republic of ", "Islamic Republic of ", "United Republic of ",
    "People's Republic of ", "Democratic People's Republic of ",
    "Socialist Republic of ", "Bolivarian Republic of ", "Federative Republic of ",
    "Commonwealth of ", "Sultanate of ", "Grand Duchy of ", "Principality of ",
    "United States of ", "Independent State of ", "Democratic Socialist Republic of ",
    "Hashemite Kingdom of ", "Arab Republic of ", "Eastern Republic of ",
    "Union of the ", "People's Democratic Republic of "
  )
  
  for (prefix in prefixes_suffixes) {
    names <- gsub(paste0("^", prefix), "", names)
  }
  
names <- case_when(
    names == "United States of America" ~ "United States of America",
    names == "Russian Federation" ~ "Russian Federation",
    names == "Czech Republic" ~ "Czechia",
    names == "Slovak Republic" ~ "Slovakia",
    names == "Türkiye" ~ "Turkey",
    names == "United Kingdom of Great Britain and Northern Ireland" ~ "United Kingdom",
    names == "Viet Nam" ~ "Vietnam",
    names == "Korea, Republic of" ~ "Republic of Korea",
    names == "Côte d'Ivoire" ~ "Cote d'Ivoire",
    names == "French Republic" ~ "France",
    TRUE ~ names  
  )
  
  return(trimws(names))
}

who_clean <- who_data %>%
  filter(Period == 2020) %>%
  select(Location, ParentLocation, FactValueNumeric) %>%
  rename(country = Location,
         region = ParentLocation,
         alcohol_consumption = FactValueNumeric) %>%
  mutate(country_std = standardize_country_name(country))

ihme_clean <- ihme_data %>%
  filter(year == 2020,
         sex_name == "Both",
         age_name == "All ages",
         measure_name == "Prevalence",
         metric_name == "Percent") %>%
  select(location_name, val) %>%
  rename(country = location_name,
         disorder_prevalence = val) %>%
  mutate(country_std = standardize_country_name(country))

world_avg <- data.frame(
  country_std = "World",
  alcohol_consumption = mean(who_clean$alcohol_consumption, na.rm = TRUE),
  disorder_prevalence = mean(ihme_clean$disorder_prevalence, na.rm = TRUE),
  region = "World"
)

combined_data <- who_clean %>%
  inner_join(ihme_clean, by = "country_std") %>%
  select(country_std, region, alcohol_consumption, disorder_prevalence) %>%
  bind_rows(world_avg)

region_mapping <- c(
  "Eastern Mediterranean" = "Asia",
  "South-East Asia" = "Asia",
  "Western Pacific" = "Asia",
  "Europe" = "Europe",
  "Americas" = "Americas",
  "Africa" = "Africa",
  "World" = "World"
)

combined_data <- combined_data %>%
  mutate(region_grouped = ifelse(region == "World", "World", region_mapping[region]))

countries_to_label <- c("Poland", "Italy", "France", "Japan", "World", "Russian Federation", "Latvia", "Czechia", "Mongolia")

main_plot <- ggplot(combined_data, 
       aes(x = alcohol_consumption, 
           y = disorder_prevalence * 100)) +
  geom_point(aes(color = region_grouped),
             alpha = 0.7, 
             size = 3) +
  geom_point(data = subset(combined_data, country_std == "World"),
             size = 6,
             shape = 21,
             fill = "grey",
             color = "black",
             stroke = 1) +
  geom_text_repel(aes(label = ifelse(country_std %in% countries_to_label, as.character(country_std), "")),
                  size = 3,
                  max.overlaps = 30,
                  box.padding = 0.5) +
  scale_x_continuous(name = "Average annual alcohol consumption (litres of pure alcohol per capita)",
                     limits = c(0, NA),
                     labels = function(x) paste0(x, "L")
                     ) +
  scale_y_continuous(name = "Share of population with alcohol use disorder (%)",
                     labels = function(x) paste0(x, "%")) +
  scale_color_manual(values = c(
    "Africa" = "#E269AB",
    "Asia" = "#4C8CBF",
    "Europe" = "#3F3F70",
    "Americas" = "#F2A900",
    "World" = "#808080"
  )) +
  theme_minimal() +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "#d0d0d0"), 
    legend.position = "right",
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 12),
    plot.background = element_rect(fill = "#efe4c9"),
    panel.background = element_rect(fill = "#efe4c9"), 
    legend.key = element_blank(), 
    legend.background = element_blank(), 
    panel.border = element_blank()
  ) +
  labs(
    color = "Region",
    x = element_blank(), 
    y = element_blank()
  )


main_plot
