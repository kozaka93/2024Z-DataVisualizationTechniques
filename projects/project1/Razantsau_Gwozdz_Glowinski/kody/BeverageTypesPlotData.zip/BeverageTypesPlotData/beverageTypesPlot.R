install.packages("dplyr")
library(dplyr)
library(ggplot2)
names(data)

#setwd("/Users/admin/Downloads")

# DATASET taken from this WHO DataWarehous 
# https://www.who.int/data/gho/data/indicators/indicator-details/GHO/alcohol-recorded-per-capita-(15-)-consumption-(in-litres-of-pure-alcohol)
data <- read.csv("data.csv")
View(data)

unique(data$Period)
names(data)
unique(data$Dim1)


filtred <- data |> 
  filter(Location %in% c("Poland", "Russian Federation", "Japan", "France", "Italy", "Czechia") &
           Dim1 %in% c("Beer", "Spirits", "Wine"))


ggplot(filtred, aes(x = Period, y = Value, fill = Dim1)) +
  geom_area() +
  facet_wrap(~Location) +
  scale_fill_manual(values = c("Beer" = "#DB8F3D", "Spirits" = "skyblue2", "Wine" = "#800020"))+
  theme_minimal() +
  labs(y = NULL, x = NULL, fill = NULL) +
  scale_y_continuous(labels = function(x) paste(x, "L"), expand = c(0, 0)) +
  scale_x_continuous(breaks = seq(1850, 2015, by = 20), expand = c(0, 0)) +
  theme(plot.background = element_rect(fill = "#efe4c9"),
        panel.background = element_rect(fill = "#efe4c9"),
        legend.background = element_blank(),
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank()
        )
